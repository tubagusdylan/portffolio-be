const mysql = require("mysql2");

const db = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "",
  database: "portfolio_db",
  connectionLimit: 100,
});

module.exports = db;
