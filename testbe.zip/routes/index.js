const express = require("express");

const router = express.Router();

const appGreetings = (req, res) => {
  try {
    res.set("Content-Type", "application/json");
    res.status(200).json({
      code: 200,
      success: true,
      message: "Halo, aplikasi sudah berjalan",
      data: {},
    });
  } catch (error) {
    res.status(503).json({
      code: 503,
      success: false,
      message: "Service tidak berjalan",
      data: {},
    });
  }
};

router.get("/", appGreetings);

module.exports = router;
