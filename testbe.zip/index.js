const express = require("express");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const dotenv = require("dotenv");
const router = require("./routes/index.js");

dotenv.config({ path: "./.env" });
const app = express();
const PORT = process.env.APP_PORT || 5000;

app.use(cors({ credentials: true, origin: "http://localhost:5173" }));
app.use(cookieParser());
app.use(express.json());
app.use(router);

app.listen(PORT, () => {
  console.log(`Server is running at port ${PORT}`);
});
